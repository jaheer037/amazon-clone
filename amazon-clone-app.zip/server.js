const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/miniAmazon1', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Schemas and Models
const userSchema = new mongoose.Schema({
    username: String,
    email: String,
    phone: String,
    password: String
});

const itemSchema = new mongoose.Schema({
    name: String,
    price: Number,
    image: String,
    category: String
});

const cartItemSchema = new mongoose.Schema({
    userId: mongoose.Schema.Types.ObjectId, // Reference to the user's ID
    cname: String, // Field to store the logged-in user's name
    items: [{ 
        name: String, 
        price: Number, 
        image: String, 
        category: String 
    }]
});
mongoose.pluralize(null);
const User = mongoose.model('User', userSchema);
const Item = mongoose.model('Item', itemSchema);
const CartItem = mongoose.model('CartItem', cartItemSchema);

// Routes

// User Registration
app.post('/register', async (req, res) => {
    const { username, email, phone, password } = req.body;
    const newUser = new User({ username, email, phone, password });
    await newUser.save();
    res.send({ message: 'User registered successfully', user: newUser });
});

// User Login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email, password });
    if (user) {
        res.send({ message: 'Login successful', user });
    } else {
        res.status(400).send({ message: 'Invalid credentials' });
    }
});

// Add Item
app.post('/items', async (req, res) => {
    const { name, price, image, category } = req.body;
    const newItem = new Item({ name, price, image, category });
    await newItem.save();
    res.send({ message: 'Item added successfully', item: newItem });
});

// Get Items by Category
app.get('/items/:category', async (req, res) => {
    const items = await Item.find({ category: req.params.category });
    res.send(items);
});

// Add to Cart
app.post('/cart', async (req, res) => {
    const { userId, items } = req.body;
    let cart = await CartItem.findOne({ userId });
    if (!cart) {
        cart = new CartItem({ userId, items });
    } else {
        cart.items.push(...items);
    }
    await cart.save();
    res.send({ message: 'Items added to cart', cart });
});

// Get Cart Items
app.get('/cart/:userId', async (req, res) => {
    const cart = await CartItem.findOne({ userId: req.params.userId });
    res.send(cart ? cart.items : []);
});

// Place Order and Clear Cart
app.post('/buy', async (req, res) => {
    const { userId } = req.body;
    await CartItem.deleteOne({ userId });
    res.send({ message: 'Order placed successfully!' });
});

// Start the server
app.listen(4000, () => {
    console.log('Server is running on port 5000');
});
